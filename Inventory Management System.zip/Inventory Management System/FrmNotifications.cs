﻿using System;
using System.Windows.Forms;

namespace InventoryManagement
{
    public partial class NotificationsForm : Form
    {
        public NotificationsForm()
        {
            InitializeComponent();
        }

        private void NotificationsForm_Load(object sender, EventArgs e)
        {
            LoadNotifications();
        }

        private void LoadNotifications()
        {
            string query = "SELECT * FROM ChangeRequests WHERE Status != 'Pending'";
            dataGridViewNotifications.DataSource = DatabaseHelper.ExecuteQuery(query);
        }
    }
}
