﻿using System;
using System.Windows.Forms;

namespace InventoryManagement
{
    public partial class ProductQuantityTrackingForm : Form
    {
        public ProductQuantityTrackingForm()
        {
            InitializeComponent();
        }

        private void btnIncrement_Click(object sender, EventArgs e)
        {
            string productId = txtProductId.Text;
            string query = $"UPDATE Products SET Quantity = Quantity + 1 WHERE ProductID = {productId}";
            DatabaseHelper.ExecuteNonQuery(query);
            MessageBox.Show("Quantity incremented successfully!");
        }

        private void btnDecrement_Click(object sender, EventArgs e)
        {
            string productId = txtProductId.Text;
            string query = $"UPDATE Products SET Quantity = Quantity - 1 WHERE ProductID = {productId}";
            DatabaseHelper.ExecuteNonQuery(query);
            MessageBox.Show("Quantity decremented successfully!");
        }
    }
}
