﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public static partial class DatabaseHelper
    {
        // Connection string to your database
        private static string connectionString = "(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\SAMSON\\source\\repos\\Inventory Management System\\IMS DB.mdf\";Integrated Security=True;Connect Timeout=30";

        // Method to get the SQL connection
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        // Method to execute a query that returns data
        public static DataTable ExecuteQuery(string query)
        {
            using (SqlConnection conn = GetConnection())  // Use the GetConnection method to get the connection
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    return dataTable;
                }
            }
        }

        // Method to execute a query that does not return data (e.g., INSERT, UPDATE, DELETE)
        public static void ExecuteNonQuery(string query)
        {
            using (SqlConnection conn = GetConnection())  // Use the GetConnection method to get the connection
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
