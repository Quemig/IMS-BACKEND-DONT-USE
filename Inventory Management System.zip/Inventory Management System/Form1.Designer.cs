﻿namespace Inventory_Management_System
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnViewProducts = new System.Windows.Forms.Button();
            this.btnTrackQuantity = new System.Windows.Forms.Button();
            this.btnIssueInvoice = new System.Windows.Forms.Button();
            this.btnManageRequests = new System.Windows.Forms.Button();
            this.btnNotifications = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnViewProducts
            // 
            this.btnViewProducts.Location = new System.Drawing.Point(50, 30);
            this.btnViewProducts.Name = "btnViewProducts";
            this.btnViewProducts.Size = new System.Drawing.Size(200, 40);
            this.btnViewProducts.TabIndex = 0;
            this.btnViewProducts.Text = "View Products";
            this.btnViewProducts.UseVisualStyleBackColor = true;
            this.btnViewProducts.Click += new System.EventHandler(this.btnViewProducts_Click);
            // 
            // btnTrackQuantity
            // 
            this.btnTrackQuantity.Location = new System.Drawing.Point(50, 80);
            this.btnTrackQuantity.Name = "btnTrackQuantity";
            this.btnTrackQuantity.Size = new System.Drawing.Size(200, 40);
            this.btnTrackQuantity.TabIndex = 1;
            this.btnTrackQuantity.Text = "Track Quantity";
            this.btnTrackQuantity.UseVisualStyleBackColor = true;
            this.btnTrackQuantity.Click += new System.EventHandler(this.btnTrackQuantity_Click);
            // 
            // btnIssueInvoice
            // 
            this.btnIssueInvoice.Location = new System.Drawing.Point(50, 130);
            this.btnIssueInvoice.Name = "btnIssueInvoice";
            this.btnIssueInvoice.Size = new System.Drawing.Size(200, 40);
            this.btnIssueInvoice.TabIndex = 2;
            this.btnIssueInvoice.Text = "Issue Invoice";
            this.btnIssueInvoice.UseVisualStyleBackColor = true;
            this.btnIssueInvoice.Click += new System.EventHandler(this.btnIssueInvoice_Click);
            // 
            // btnManageRequests
            // 
            this.btnManageRequests.Location = new System.Drawing.Point(50, 180);
            this.btnManageRequests.Name = "btnManageRequests";
            this.btnManageRequests.Size = new System.Drawing.Size(200, 40);
            this.btnManageRequests.TabIndex = 3;
            this.btnManageRequests.Text = "Manage Requests";
            this.btnManageRequests.UseVisualStyleBackColor = true;
            this.btnManageRequests.Click += new System.EventHandler(this.btnManageRequests_Click);
            // 
            // btnNotifications
            // 
            this.btnNotifications.Location = new System.Drawing.Point(50, 230);
            this.btnNotifications.Name = "btnNotifications";
            this.btnNotifications.Size = new System.Drawing.Size(200, 40);
            this.btnNotifications.TabIndex = 4;
            this.btnNotifications.Text = "View Notifications";
            this.btnNotifications.UseVisualStyleBackColor = true;
            this.btnNotifications.Click += new System.EventHandler(this.btnNotifications_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 300);
            this.Controls.Add(this.btnNotifications);
            this.Controls.Add(this.btnManageRequests);
            this.Controls.Add(this.btnIssueInvoice);
            this.Controls.Add(this.btnTrackQuantity);
            this.Controls.Add(this.btnViewProducts);
            this.Name = "Form1";
            this.Text = "Inventory Management";
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button btnViewProducts;
        private System.Windows.Forms.Button btnTrackQuantity;
        private System.Windows.Forms.Button btnIssueInvoice;
        private System.Windows.Forms.Button btnManageRequests;
        private System.Windows.Forms.Button btnNotifications;
    }
}
