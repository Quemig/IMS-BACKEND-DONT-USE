﻿using System;
using System.Windows.Forms;

namespace Inventory_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnViewProducts_Click(object sender, EventArgs e)
        {
            ProductInfoDisplayForm productForm = new ProductInfoDisplayForm();
            productForm.Show();
        }

        private void btnTrackQuantity_Click(object sender, EventArgs e)
        {
            ProductQuantityTrackingForm quantityForm = new ProductQuantityTrackingForm();
            quantityForm.Show();
        }

        private void btnIssueInvoice_Click(object sender, EventArgs e)
        {
            ProductInvoiceForm invoiceForm = new ProductInvoiceForm();
            invoiceForm.Show();
        }

        private void btnManageRequests_Click(object sender, EventArgs e)
        {
            InventoryChangeRequestForm requestForm = new InventoryChangeRequestForm();
            requestForm.Show();
        }

        private void btnNotifications_Click(object sender, EventArgs e)
        {
            NotificationsForm notificationsForm = new NotificationsForm();
            notificationsForm.Show();
        }
    }
}
