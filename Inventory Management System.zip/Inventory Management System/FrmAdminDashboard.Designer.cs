﻿namespace Inventory_Management_System
{
    partial class FrmAdminDashboard
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnManageProducts;
        private System.Windows.Forms.Button btnApproveRequests;
        private System.Windows.Forms.Button btnLogout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnManageProducts = new System.Windows.Forms.Button();
            this.btnApproveRequests = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // 
            // btnManageProducts
            // 
            this.btnManageProducts.Location = new System.Drawing.Point(50, 50);
            this.btnManageProducts.Name = "btnManageProducts";
            this.btnManageProducts.Size = new System.Drawing.Size(200, 50);
            this.btnManageProducts.TabIndex = 0;
            this.btnManageProducts.Text = "Manage Products";
            this.btnManageProducts.UseVisualStyleBackColor = true;
            this.btnManageProducts.Click += new System.EventHandler(this.btnManageProducts_Click);

            // 
            // btnApproveRequests
            // 
            this.btnApproveRequests.Location = new System.Drawing.Point(50, 150);
            this.btnApproveRequests.Name = "btnApproveRequests";
            this.btnApproveRequests.Size = new System.Drawing.Size(200, 50);
            this.btnApproveRequests.TabIndex = 1;
            this.btnApproveRequests.Text = "Approve Requests";
            this.btnApproveRequests.UseVisualStyleBackColor = true;
            this.btnApproveRequests.Click += new System.EventHandler(this.btnApproveRequests_Click);

            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(50, 250);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(200, 50);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);

            // 
            // FrmAdminDashboard
            // 
            this.ClientSize = new System.Drawing.Size(300, 350);
            this.Controls.Add(this.btnManageProducts);
            this.Controls.Add(this.btnApproveRequests);
            this.Controls.Add(this.btnLogout);
            this.Name = "FrmAdminDashboard";
            this.Text = "Admin Dashboard";
            this.ResumeLayout(false);
        }
    }
}
