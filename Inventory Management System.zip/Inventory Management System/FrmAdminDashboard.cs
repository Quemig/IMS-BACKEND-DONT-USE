﻿using System;
using System.Windows.Forms;

namespace Inventory_Management_System
{
    public partial class FrmAdminDashboard : Form
    {
        public FrmAdminDashboard()
        {
            InitializeComponent();
        }

        // Button to manage products
        private void btnManageProducts_Click(object sender, EventArgs e)
        {
            FrmManageProducts manageProductsForm = new FrmManageProducts();
            manageProductsForm.Show();
        }

        // Button to approve/reject inventory change requests
        private void btnApproveRequests_Click(object sender, EventArgs e)
        {
            FrmApproveRequests approveRequestsForm = new FrmApproveRequests();
            approveRequestsForm.Show();
        }

        // Button to log out
        private void btnLogout_Click(object sender, EventArgs e)
        {
            FrmLogin loginForm = new FrmLogin();
            loginForm.Show();
            this.Close();
        }
    }
}
