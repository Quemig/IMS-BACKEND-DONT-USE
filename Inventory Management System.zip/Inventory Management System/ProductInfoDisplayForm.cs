﻿using System;
using System.Windows.Forms;

namespace Inventory_Management_System
{
    public partial class ProductInfoDisplayForm : Form
    {
        public ProductInfoDisplayForm()
        {
            InitializeComponent();
        }

        private void ProductInfoDisplayForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void LoadProducts()
        {
            string query = "SELECT * FROM Products";
            dataGridViewProducts.DataSource = DatabaseHelper.ExecuteQuery(query);
        }
    }
}
