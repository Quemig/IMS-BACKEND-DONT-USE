﻿using System;
using System.Windows.Forms;

namespace InventoryManagement
{
    public partial class ProductInvoiceForm : Form
    {
        public ProductInvoiceForm()
        {
            InitializeComponent();
        }
    }
}
