﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Inventory_Management_System
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Query to validate the user
            string query = "SELECT Role FROM Users WHERE Username = @username AND Password = @password";

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password); // Hash password in production for security!

                conn.Open();
                object roleObj = cmd.ExecuteScalar();

                if (roleObj != null)
                {
                    string role = roleObj.ToString();

                    // Redirect based on role
                    if (role == "Admin")
                    {
                        FrmAdminDashboard adminDashboard = new FrmAdminDashboard();
                        adminDashboard.Show();
                    }
                    else if (role == "User")
                    {
                        FrmUserDashboard userDashboard = new FrmUserDashboard();
                        userDashboard.Show();
                    }

                    this.Hide(); // Hide the login form
                }
                else
                {
                    MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
