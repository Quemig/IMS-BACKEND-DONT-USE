﻿using InventoryManagement;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
    public partial class FrmInventoryChangeRequest : Form
    {
        public FrmInventoryChangeRequest()
        {
            InitializeComponent();
        }

        private void FrmInventoryChangeRequest_Load(object sender, EventArgs e)
        {
            LoadPendingRequests();
        }

        private void LoadPendingRequests()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();

                    string query = "SELECT RequestID, ProductID, RequestedBy, ChangeType, QuantityChange, Status FROM ChangeRequests WHERE Status = 'Pending'";
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable requests = new DataTable();
                        adapter.Fill(requests);

                        dataGridViewRequests.DataSource = requests;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading requests: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            if (dataGridViewRequests.SelectedRows.Count > 0)
            {
                int requestId = Convert.ToInt32(dataGridViewRequests.SelectedRows[0].Cells["RequestID"].Value);
                ApproveRequest(requestId);
            }
            else
            {
                MessageBox.Show("Please select a request to approve.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDecline_Click(object sender, EventArgs e)
        {
            if (dataGridViewRequests.SelectedRows.Count > 0)
            {
                int requestId = Convert.ToInt32(dataGridViewRequests.SelectedRows[0].Cells["RequestID"].Value);
                DeclineRequest(requestId);
            }
            else
            {
                MessageBox.Show("Please select a request to decline.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ApproveRequest(int requestId)
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();

                    // Update the request status to Approved
                    string updateQuery = "UPDATE ChangeRequests SET Status = 'Approved' WHERE RequestID = @RequestID";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@RequestID", requestId);
                        cmd.ExecuteNonQuery();
                    }

                    // Reflect the change in the Products table
                    string updateProductQuery = @"
                        UPDATE Products
                        SET Quantity = Quantity +
                        (SELECT CASE WHEN ChangeType = 'Increment' THEN QuantityChange ELSE -QuantityChange END
                         FROM ChangeRequests WHERE RequestID = @RequestID)
                        WHERE ProductID = (SELECT ProductID FROM ChangeRequests WHERE RequestID = @RequestID)";

                    using (SqlCommand cmd = new SqlCommand(updateProductQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@RequestID", requestId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Request approved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadPendingRequests();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error approving request: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeclineRequest(int requestId)
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();

                    string query = "UPDATE ChangeRequests SET Status = 'Declined' WHERE RequestID = @RequestID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@RequestID", requestId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Request declined successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadPendingRequests();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error declining request: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
