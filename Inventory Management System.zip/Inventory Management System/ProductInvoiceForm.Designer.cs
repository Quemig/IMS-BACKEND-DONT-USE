﻿namespace InventoryManagement
{
    partial class ProductInvoiceForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblInvoiceTitle = new System.Windows.Forms.Label();
            this.txtInvoiceDetails = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblInvoiceTitle
            // 
            this.lblInvoiceTitle.AutoSize = true;
            this.lblInvoiceTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblInvoiceTitle.Location = new System.Drawing.Point(12, 9);
            this.lblInvoiceTitle.Name = "lblInvoiceTitle";
            this.lblInvoiceTitle.Size = new System.Drawing.Size(72, 20);
            this.lblInvoiceTitle.TabIndex = 0;
            this.lblInvoiceTitle.Text = "Invoice:";
            // 
            // txtInvoiceDetails
            // 
            this.txtInvoiceDetails.Location = new System.Drawing.Point(16, 41);
            this.txtInvoiceDetails.Multiline = true;
            this.txtInvoiceDetails.Name = "txtInvoiceDetails";
            this.txtInvoiceDetails.ReadOnly = true;
            this.txtInvoiceDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInvoiceDetails.Size = new System.Drawing.Size(400, 200);
            this.txtInvoiceDetails.TabIndex = 1;
            // 
            // ProductInvoiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 261);
            this.Controls.Add(this.txtInvoiceDetails);
            this.Controls.Add(this.lblInvoiceTitle);
            this.Name = "ProductInvoiceForm";
            this.Text = "Invoice";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblInvoiceTitle;
        private System.Windows.Forms.TextBox txtInvoiceDetails;
    }
}
